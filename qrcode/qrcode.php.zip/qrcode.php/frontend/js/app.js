// Configuração da API
const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
const API_BASE_URL = isLocal
    ? window.location.href.substring(0, window.location.href.lastIndexOf('/frontend')) + '/backend/public/index.php'
    : 'https://seu-dominio.com.br/backend/public/index.php';

// Inicializa ícones
lucide.createIcons();

// Elementos do DOM
const form = document.getElementById('scanForm');
const input = document.getElementById('codeInput');
const listContainer = document.getElementById('dataList');
const emptyState = document.getElementById('emptyState');
const itemCount = document.getElementById('itemCount');
const btnSimulateScan = document.getElementById('btnSimulateScan');
const btnClearAll = document.getElementById('btnClearAll');
const btnSendEmail = document.getElementById('btnSendEmail');
const toast = document.getElementById('toast');
const toastMsg = document.getElementById('toastMsg');

// Elementos do Modal da Câmera
const cameraModal = document.getElementById('cameraModal');
const cameraVideo = document.getElementById('cameraVideo');
const qrCanvas = document.getElementById('qrCanvas');
const qrContext = qrCanvas ? qrCanvas.getContext('2d', { willReadFrequently: true }) : null;
const btnCloseCamera = document.getElementById('btnCloseCamera');
const btnSimulateCapture = document.getElementById('btnSimulateCapture');

// Elementos da Sidebar
const btnMenu = document.getElementById('btnMenu');
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const btnCloseSidebar = document.getElementById('btnCloseSidebar');

let cameraStream = null;
let isScanning = false;

// Função para mostrar notificação rápida
function showToast(message, type = 'success') {
    toastMsg.textContent = message;
    toast.style.background = type === 'success' ? '#28a745' : '#dc3545';
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2500);
}

// Função para formatar data e hora
function formatDateTime(dbDate) {
    const date = new Date(dbDate);
    return date.toLocaleDateString('pt-PT') + ' às ' + date.toLocaleTimeString('pt-PT');
}

// Função para carregar itens da API
async function loadItems() {
    try {
        const response = await fetch(`${API_BASE_URL}/items`);
        const items = await response.json();
        renderList(items);
    } catch (error) {
        console.error('Erro ao carregar itens:', error);
        showToast('Erro ao carregar dados do servidor', 'error');
    }
}

// Função para renderizar a lista
function renderList(items) {
    listContainer.innerHTML = '';
    itemCount.textContent = items.length;

    if (items.length === 0) {
        emptyState.style.display = 'flex';
        btnSendEmail.disabled = true;
        btnSendEmail.style.opacity = '0.5';
    } else {
        emptyState.style.display = 'none';
        btnSendEmail.disabled = false;
        btnSendEmail.style.opacity = '1';

        items.forEach(item => {
            const li = document.createElement('li');
            li.className = 'data-item';
            li.innerHTML = `
                <div class="item-info">
                    <span class="item-code">${item.code}</span>
                    <span class="item-time"><i data-lucide="clock" width="10" height="10" style="display:inline; margin-right:3px;"></i>${formatDateTime(item.timestamp)}</span>
                </div>
                <button class="btn-delete-item" onclick="deleteItemById(${item.id})" title="Remover item">
                    <i data-lucide="trash-2" width="16" height="16"></i>
                </button>
            `;
            listContainer.appendChild(li);
        });

        // Recria os ícones inseridos dinamicamente
        lucide.createIcons();
    }
}

// Função global para deletar item por ID
window.deleteItemById = async function (id) {
    if (!confirm('Deseja remover este item da lista?')) return;

    try {
        const response = await fetch(`${API_BASE_URL}/items/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showToast('Item removido com sucesso!');
            loadItems();
        } else {
            showToast('Erro ao remover item', 'error');
        }
    } catch (error) {
        console.error('Erro ao deletar item:', error);
        showToast('Erro de conexão ao remover', 'error');
    }
};

// Adicionar novo código à API
async function addCode(code) {
    if (!code.trim()) return;

    try {
        const response = await fetch(`${API_BASE_URL}/items`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code: code.trim() })
        });

        const result = await response.json();

        if (response.ok) {
            showToast('Código registrado!');
            input.value = '';
            loadItems();
        } else {
            showToast(result.error || 'Erro ao registrar', 'error');
            input.value = '';
        }
        input.focus();
    } catch (error) {
        console.error('Erro ao registrar item:', error);
        showToast('Erro de conexão com o servidor', 'error');
    }
}

// Evento: Submissão do formulário
form.addEventListener('submit', (e) => {
    e.preventDefault();
    addCode(input.value);
});

// --- Lógica da Câmera ---
async function startCamera() {
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' }
        });
        if (cameraVideo) {
            cameraVideo.srcObject = cameraStream;
            isScanning = true;
            requestAnimationFrame(tick);
        }
    } catch (error) {
        console.error('Erro ao acessar a câmera:', error);
        showToast('Não foi possível acessar a câmera', 'error');
    }
}

function stopCamera() {
    isScanning = false;
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    if (cameraVideo) {
        cameraVideo.srcObject = null;
    }
}

function tick() {
    if (!isScanning) return;

    if (cameraVideo && cameraVideo.readyState === cameraVideo.HAVE_ENOUGH_DATA) {
        qrCanvas.height = cameraVideo.videoHeight;
        qrCanvas.width = cameraVideo.videoWidth;
        qrContext.drawImage(cameraVideo, 0, 0, qrCanvas.width, qrCanvas.height);

        const imageData = qrContext.getImageData(0, 0, qrCanvas.width, qrCanvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: "dontInvert",
        });

        if (code && code.data) {
            console.log("QR Code detectado!", code.data);
            isScanning = false;

            // Feedback tátil
            if (navigator.vibrate) navigator.vibrate(200);

            addCode(code.data);
            cameraModal.style.display = 'none';
            stopCamera();
            return;
        }
    }
    requestAnimationFrame(tick);
}

// Evento: Abrir Modal da Câmera
btnSimulateScan.addEventListener('click', () => {
    cameraModal.style.display = 'flex';
    startCamera();
    lucide.createIcons();
});

// Evento: Fechar Modal da Câmera
btnCloseCamera.addEventListener('click', () => {
    cameraModal.style.display = 'none';
    stopCamera();
});

// Evento: Botão Simular Captura no Modal
btnSimulateCapture.addEventListener('click', () => {
    const randomCode = 'CTE' + Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
    addCode(randomCode);
    cameraModal.style.display = 'none';
    stopCamera();
});

// --- Lógica da Sidebar ---
function openSidebar() {
    if (sidebar && sidebarOverlay) {
        sidebar.style.right = '0';
        sidebarOverlay.style.visibility = 'visible';
        sidebarOverlay.style.opacity = '1';
    }
}

function closeSidebar() {
    if (sidebar && sidebarOverlay) {
        sidebar.style.right = '-270px';
        sidebarOverlay.style.opacity = '0';
        setTimeout(() => {
            if (sidebarOverlay.style.opacity === '0') {
                sidebarOverlay.style.visibility = 'hidden';
            }
        }, 300);
    }
}

if (btnMenu) btnMenu.addEventListener('click', openSidebar);
if (btnCloseSidebar) btnCloseSidebar.addEventListener('click', closeSidebar);
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

// Elementos do Modal de Confirmação
const confirmModal = document.getElementById('confirmModal');
const btnCancelClear = document.getElementById('btnCancelClear');
const btnConfirmClear = document.getElementById('btnConfirmClear');

// Evento: Abrir modal de Limpar Tudo
btnClearAll.addEventListener('click', () => {
    confirmModal.style.display = 'flex';
});

// Evento: Fechar modal (Cancelar)
btnCancelClear.addEventListener('click', () => {
    confirmModal.style.display = 'none';
});

// Evento: Confirmar limpeza
btnConfirmClear.addEventListener('click', async () => {
    confirmModal.style.display = 'none'; // Fecha o modal primeiro
    try {
        const response = await fetch(`${API_BASE_URL}/items`, { method: 'DELETE' });
        if (response.ok) {
            showToast('Lista limpa com sucesso!');
            loadItems();
        } else {
            showToast('Erro ao limpar lista', 'error');
        }
    } catch (error) {
        showToast('Erro ao conectar', 'error');
    }
});

// --- Dados das Filiais Fachini ---
const branches = [
    { name: 'Votuporanga – SP (Sede)', location: 'Votuporanga, SP', state: 'SP' },
    { name: 'São José do Rio Preto – SP', location: 'São José do Rio Preto, SP', state: 'SP' },
    { name: 'Mirassol – SP', location: 'Mirassol, SP', state: 'SP' },
    { name: 'Cosmorama – SP', location: 'Cosmorama, SP', state: 'SP' },
    { name: 'Coroados – SP', location: 'Coroados, SP', state: 'SP' },
    { name: 'Ribeirão Preto – SP', location: 'Ribeirão Preto, SP', state: 'SP' },
    { name: 'Guararema – SP', location: 'Guararema, SP', state: 'SP' },
    { name: 'Guarulhos – SP', location: 'Guarulhos, SP', state: 'SP' },
    { name: 'Anápolis – GO', location: 'Anápolis, GO', state: 'GO' },
    { name: 'Rio Verde – GO', location: 'Rio Verde, GO', state: 'GO' },
    { name: 'Cuiabá – MT', location: 'Cuiabá, MT', state: 'MT' },
    { name: 'Rondonópolis – MT', location: 'Rondonópolis, MT', state: 'MT' },
    { name: 'Campo Grande – MS', location: 'Campo Grande, MS', state: 'MS' },
    { name: 'Ribas do Rio Pardo – MS', location: 'Ribas do Rio Pardo, MS', state: 'MS' },
    { name: 'Chapecó – SC', location: 'Chapecó, SC', state: 'SC' },
    { name: 'Penha – SC', location: 'Penha, SC', state: 'SC' },
    { name: 'Içara – SC', location: 'Içara, SC', state: 'SC' },
    { name: 'São José dos Pinhais – PR', location: 'São José dos Pinhais, PR', state: 'PR' },
    { name: 'Cambé – PR', location: 'Cambé, PR', state: 'PR' },
    { name: 'Nova Santa Rita – RS', location: 'Nova Santa Rita, RS', state: 'RS' },
    { name: 'Imperatriz – MA', location: 'Imperatriz, MA', state: 'MA' },
    { name: 'São José de Mipibu – RN', location: 'São José de Mipibu, RN', state: 'RN' },
    { name: 'Cabo de Santo Agostinho – PE', location: 'Cabo de Santo Agostinho, PE', state: 'PE' },
    { name: 'Luís Eduardo Magalhães – BA', location: 'Luís Eduardo Magalhães, BA', state: 'BA' },
    { name: 'Palmas – TO', location: 'Palmas, TO', state: 'TO' }
];

// Elementos dos Modais de Destino
const destinationModal = document.getElementById('destinationModal');
const branchSelectionModal = document.getElementById('branchSelectionModal');
const fieldSelectBranch = document.getElementById('fieldSelectBranch');
const destinationInput = document.getElementById('destinationInput');
const btnConfirmSend = document.getElementById('btnConfirmSend');
const btnCancelSend = document.getElementById('btnCancelSend');
const btnCloseBranchSelection = document.getElementById('btnCloseBranchSelection');
const branchListContainer = document.getElementById('branchList');
const filterStatesContainer = document.getElementById('filterStates');
const branchSearch = document.getElementById('branchSearch');

let selectedState = null;

// Função para renderizar filtros de estado
function renderFilterStates() {
    if (!filterStatesContainer) return;
    const states = [...new Set(branches.map(b => b.state))].sort();
    filterStatesContainer.innerHTML = `<span class="filter-chip ${!selectedState ? 'active' : ''}" onclick="filterByState(null)">Todos</span>`;
    states.forEach(state => {
        filterStatesContainer.innerHTML += `<span class="filter-chip ${selectedState === state ? 'active' : ''}" onclick="filterByState('${state}')">${state}</span>`;
    });
}

// Global para fácil acesso via onclick inline (estratégia rápida)
window.filterByState = (state) => {
    selectedState = state;
    renderFilterStates();
    renderBranchList();
};

window.selectBranch = (branchName) => {
    destinationInput.value = branchName;
    btnConfirmSend.disabled = false;
    btnConfirmSend.style.opacity = '1';
    branchSelectionModal.style.display = 'none';
};

// Função para renderizar lista de filiais
function renderBranchList() {
    if (!branchListContainer) return;
    const searchTerm = branchSearch.value.toLowerCase();
    const filtered = branches.filter(b => {
        const matchesState = !selectedState || b.state === selectedState;
        const matchesSearch = b.name.toLowerCase().includes(searchTerm) || b.location.toLowerCase().includes(searchTerm);
        return matchesState && matchesSearch;
    });

    branchListContainer.innerHTML = '';
    filtered.forEach(branch => {
        const div = document.createElement('div');
        div.className = 'branch-item';
        div.onclick = () => selectBranch(branch.name);
        div.innerHTML = `
            <span class="branch-name">${branch.name}</span>
            <span class="branch-location"><i data-lucide="map-pin" width="12" height="12"></i> ${branch.location}</span>
        `;
        branchListContainer.appendChild(div);
    });
    lucide.createIcons();
}

// Eventos de Navegação dos Modais
if (btnSendEmail) {
    btnSendEmail.addEventListener('click', () => {
        destinationModal.style.display = 'flex';
        lucide.createIcons();
    });
}

if (fieldSelectBranch) {
    fieldSelectBranch.addEventListener('click', () => {
        branchSelectionModal.style.display = 'flex';
        renderFilterStates();
        renderBranchList();
    });
}

if (btnCloseBranchSelection) {
    btnCloseBranchSelection.addEventListener('click', () => {
        branchSelectionModal.style.display = 'none';
    });
}

if (btnCancelSend) {
    btnCancelSend.addEventListener('click', () => {
        destinationModal.style.display = 'none';
        destinationInput.value = '';
        btnConfirmSend.disabled = true;
        btnConfirmSend.style.opacity = '0.6';
    });
}

if (branchSearch) {
    branchSearch.addEventListener('input', renderBranchList);
}

// --- Lógica Final de Envio com Animação ---
if (btnConfirmSend) {
    btnConfirmSend.addEventListener('click', async () => {
        destinationModal.style.display = 'none';

        // Iniciar Animação do Caminhão
        const truckIcon = document.querySelector('.truck-wrapper');
        const logoText = document.querySelector('.logo-text');

        if (truckIcon && logoText) {
            const header = truckIcon.closest('.header');
            const headerWidth = header.clientWidth;
            const stopDistance = headerWidth - 100;

            truckIcon.style.setProperty('--drive-dist', `${stopDistance}px`);
            truckIcon.classList.add('truck-driving');
            logoText.classList.add('hide-logo');

            showToast('Finalizando e enviando...', 'success');

            // Aguarda a animação e depois faz reset + envia
            setTimeout(async () => {
                // Reset suave: remove animação e restaura posição
                truckIcon.classList.remove('truck-driving');
                truckIcon.style.transition = 'none';
                truckIcon.style.transform = 'translateX(0)';
                truckIcon.style.opacity = '1';
                // Força reflow para aplicar imediatamente
                void truckIcon.offsetWidth;
                truckIcon.style.transition = '';

                logoText.classList.remove('hide-logo');
                logoText.style.clipPath = 'inset(0 0 0 0)';
                logoText.style.opacity = '1';

                // Processar Envio Real
                try {
                    const response = await fetch(`${API_BASE_URL}/report`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ destination: destinationInput.value })
                    });

                    if (response.ok) {
                        showToast('Relatório enviado com sucesso!');
                        loadItems();
                        destinationInput.value = '';
                        btnConfirmSend.disabled = true;
                        btnConfirmSend.style.opacity = '0.5';
                    } else {
                        showToast('Erro no envio do relatório', 'error');
                    }
                } catch (error) {
                    showToast('Erro de conexão ao enviar', 'error');
                }
            }, 2500);

        }
    });
}

// Inicialização
loadItems();
input.focus();

// Lógica da Tela de Splash com Carrossel
const btnEnterApp = document.getElementById('btnEnterApp');
const splashScreen = document.getElementById('splashScreen');
const appContainer = document.querySelector('.app-container');
const progressBar = document.querySelector('.progress-bar');
const carouselItems = document.querySelectorAll('.carousel-item');
const carouselContainer = document.querySelector('.carousel-container');

let currentSlide = 1;
let autoRotateInterval = null;

function updateCarousel() {
    carouselItems.forEach((item, index) => {
        item.classList.remove('active', 'prev', 'next', 'hidden');

        if (index === currentSlide) {
            item.classList.add('active');
        } else if (index === (currentSlide - 1 + carouselItems.length) % carouselItems.length) {
            item.classList.add('prev');
        } else if (index === (currentSlide + 1) % carouselItems.length) {
            item.classList.add('next');
        } else {
            item.classList.add('hidden');
        }
    });
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % carouselItems.length;
    updateCarousel();
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + carouselItems.length) % carouselItems.length;
    updateCarousel();
}

// Auto-rotação
function startAutoRotate() {
    stopAutoRotate();
    autoRotateInterval = setInterval(nextSlide, 800);
}

function stopAutoRotate() {
    if (autoRotateInterval) {
        clearInterval(autoRotateInterval);
        autoRotateInterval = null;
    }
}

// Clique nas imagens: muda o slide e ativa auto-rotação
carouselItems.forEach((item, index) => {
    item.addEventListener('click', () => {
        currentSlide = index;
        updateCarousel();
        startAutoRotate();
    });
});

// ---- Suporte a Swipe (Touch) ----
let touchStartX = 0;
let touchEndX = 0;
let isSwiping = false;

if (carouselContainer) {
    carouselContainer.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        isSwiping = true;
        stopAutoRotate();
    }, { passive: true });

    carouselContainer.addEventListener('touchmove', (e) => {
        touchEndX = e.changedTouches[0].screenX;
    }, { passive: true });

    carouselContainer.addEventListener('touchend', () => {
        if (!isSwiping) return;
        isSwiping = false;

        const diff = touchStartX - touchEndX;
        const threshold = 40; // sensibilidade do swipe

        if (Math.abs(diff) > threshold) {
            if (diff > 0) {
                nextSlide(); // swipe para a esquerda → próximo
            } else {
                prevSlide(); // swipe para a direita → anterior
            }
        }
    });

    // ---- Suporte a Mouse Drag (Desktop) ----
    let mouseStartX = 0;
    let isDragging = false;

    carouselContainer.addEventListener('mousedown', (e) => {
        mouseStartX = e.clientX;
        isDragging = true;
        stopAutoRotate();
        e.preventDefault();
    });

    carouselContainer.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        touchEndX = e.clientX;
    });

    carouselContainer.addEventListener('mouseup', () => {
        if (!isDragging) return;
        isDragging = false;

        const diff = mouseStartX - touchEndX;
        const threshold = 40;

        if (Math.abs(diff) > threshold) {
            if (diff > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    });

    carouselContainer.addEventListener('mouseleave', () => {
        isDragging = false;
    });
}

if (btnEnterApp && splashScreen && appContainer) {
    // Verifica se veio de outra página pela sidebar
    const urlParams = new URLSearchParams(window.location.search);
    const cameFromSidebar = urlParams.get('from') === 'sidebar';

    if (cameFromSidebar) {
        // Pula a splash screen — vai direto pro app
        splashScreen.style.display = 'none';
        appContainer.style.opacity = '1';
        // Limpa o parâmetro da URL sem recarregar
        window.history.replaceState({}, '', window.location.pathname);
        setTimeout(() => input.focus(), 100);
    } else {
        // Fluxo normal com animação
        let progress = 0;
        const interval = setInterval(() => {
            progress += 2;
            if (progressBar) progressBar.style.width = `${progress}%`;

            if (progress >= 100) {
                clearInterval(interval);
                btnEnterApp.classList.add('show');
            }
        }, 30);

        btnEnterApp.addEventListener('click', () => {
            stopAutoRotate();
            splashScreen.classList.add('fade-out');
            appContainer.classList.add('reveal');
            setTimeout(() => input.focus(), 500);
        });
    }
}
